// JHMM-17.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-17 - O Sensor do Parque Temático                          *");
    printf("\n********************************************************************************\n");

    int altura;
    printf("Altura em cm: ");
    scanf("%d", &altura);
    if (altura >= 140) {
        printf("Luz Verde (Liberado)\n");
    } else {
        printf("Luz Vermelha (Barrado)\n");
    }

    return 0;
}
