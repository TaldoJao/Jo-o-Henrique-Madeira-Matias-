
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-17.c
*/

int main() {
    int altura;
    printf("Altura em cm: ");
    scanf("%d", &altura);

    if (altura >= 140) {
        printf("Luz Verde (Liberado)\n");
    } else {
        printf("Luz Vermelha (Barrado)\n");
    }

    return 0;
}
