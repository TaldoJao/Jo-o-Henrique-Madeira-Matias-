
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-55.c
*/

int main() {
    float n, maior = -1;
    do {
        printf("Número: ");
        scanf("%f", &n);
        if (n > maior) maior = n;
    } while (n >= 0);
    if (maior >= 0) printf("Maior: %.2f\n", maior);
    return 0;
}
