// JHMM-55.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-55 - Ler números e mostrar o maior (até digitar negativ   *");
    printf("\n********************************************************************************\n");

    float n, maior = -1;
    do {
        printf("Número: ");
        scanf("%f", &n);
        if (n > maior) maior = n;
    } while (n >= 0);
    if (maior >= 0) printf("Maior: %.2f\n", maior);

    return 0;
}
