
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-37.c
*/

int main() {
    float n, soma = 0;
    printf("Digite números (0 para sair):\n");
    while (1) {
        scanf("%f", &n);
        if (n == 0) break;
        soma += n;
    }
    printf("Soma total: %.2f\n", soma);
    return 0;
}
