// JHMM-37.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-37 - Soma de números até digitar zero                     *");
    printf("\n********************************************************************************\n");

    float n, soma = 0;
    printf("Digite números (0 para sair):\n");
    while (1) {
        scanf("%f", &n);
        if (n == 0) break;
        soma += n;
    }
    printf("Soma total: %.2f\n", soma);

    return 0;
}
