// JHMM-60.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-60 - O Validador de Dias Úteis (switch...case)            *");
    printf("\n********************************************************************************\n");

    int dia;
    printf("Dia (1-7): ");
    scanf("%d", &dia);
    switch (dia) {
        case 2: case 3: case 4: case 5: case 6:
            printf("Dia Útil. Acesso liberado para o trabalho.\n");
            break;
        case 1: case 7:
            printf("Fim de Semana. Prédio fechado.\n");
            break;
        default:
            printf("Número de dia inválido.\n");
    }

    return 0;
}
