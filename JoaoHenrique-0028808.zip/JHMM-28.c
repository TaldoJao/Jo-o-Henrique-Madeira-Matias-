// JHMM-28.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-28 - Soma dos 100 primeiros números naturais              *");
    printf("\n********************************************************************************\n");

    int soma = 0;
    for (int i = 1; i <= 100; i++) {
        soma += i;
    }
    printf("Soma: %d\n", soma);

    return 0;
}
