
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-14.c
*/

int main() {
    float a, b, c;
    printf("Digite os três lados do triângulo: ");
    scanf("%f %f %f", &a, &b, &c);

    if (a == b && b == c) {
        printf("Equilátero\n");
    } else if (a == b || b == c || a == c) {
        printf("Isósceles\n");
    } else {
        printf("Escaleno\n");
    }

    return 0;
}
