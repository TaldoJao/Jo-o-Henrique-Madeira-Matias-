// JHMM-14.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-14 - Tipo de Triângulo                                    *");
    printf("\n********************************************************************************\n");

    float a, b, c;
    printf("Digite os três lados do triângulo: ");
    scanf("%f %f %f", &a, &b, &c);

    if (a == b && b == c) {
        printf("Equilátero\n");
    } else if (a == b || b == c || a == c) {
        printf("Isósceles\n");
    } else {
        printf("Escaleno\n");
    }

    return 0;
}
