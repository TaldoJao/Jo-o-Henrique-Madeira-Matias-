// JHMM-50.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-50 - Número positivo obrigatório (do...while)             *");
    printf("\n********************************************************************************\n");

    float n;
    do {
        printf("Digite um número positivo: ");
        scanf("%f", &n);
    } while (n <= 0);
    printf("Número aceito: %.2f\n", n);

    return 0;
}
