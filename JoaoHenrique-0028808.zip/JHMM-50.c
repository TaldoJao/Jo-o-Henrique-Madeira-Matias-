
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-50.c
*/

int main() {
    float n;
    do {
        printf("Digite um número positivo: ");
        scanf("%f", &n);
    } while (n <= 0);
    printf("Número aceito: %.2f\n", n);
    return 0;
}
