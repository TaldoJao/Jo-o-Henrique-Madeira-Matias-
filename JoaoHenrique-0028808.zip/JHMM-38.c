
#include <stdio.h>
#include <string.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-38.c
*/

int main() {
    char senha[20];
    while (1) {
        printf("Senha: ");
        scanf("%s", senha);
        if (strcmp(senha, "1234") == 0) {
            printf("Acesso liberado!\n");
            break;
        }
        printf("Incorreta! Tente novamente.\n");
    }
    return 0;
}
