// JHMM-38.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-38 - Senha correta                                        *");
    printf("\n********************************************************************************\n");

    char senha[20];
    while (1) {
        printf("Senha: ");
        scanf("%s", senha);
        if (strcmp(senha, "1234") == 0) {
            printf("Acesso liberado!\n");
            break;
        }
        printf("Incorreta! Tente novamente.\n");
    }

    return 0;
}
