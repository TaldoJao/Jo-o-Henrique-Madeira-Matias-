
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-54.c
*/

int main() {
    int n;
    do {
        printf("Nível (1-5): ");
        scanf("%d", &n);
    } while (n < 1 || n > 5);
    printf("Nível %d selecionado.\n", n);
    return 0;
}
