// JHMM-54.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-54 - Validar número entre 1 e 5 (do...while)              *");
    printf("\n********************************************************************************\n");

    int n;
    do {
        printf("Nível (1-5): ");
        scanf("%d", &n);
    } while (n < 1 || n > 5);
    printf("Nível %d selecionado.\n", n);

    return 0;
}
