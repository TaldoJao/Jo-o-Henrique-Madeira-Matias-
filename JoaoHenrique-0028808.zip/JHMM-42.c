// JHMM-42.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-42 - Quantidade de números ímpares digitados              *");
    printf("\n********************************************************************************\n");

    int n, impares = 0, i = 0;
    while (i < 10) {
        printf("Digite um número (%d/10): ", i+1);
        scanf("%d", &n);
        if (n % 2 != 0) impares++;
        i++;
    }
    printf("Total de ímpares: %d\n", impares);

    return 0;
}
