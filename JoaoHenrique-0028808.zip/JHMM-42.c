
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-42.c
*/

int main() {
    int n, impares = 0, i = 0;
    while (i < 10) {
        printf("Digite um número (%d/10): ", i+1);
        scanf("%d", &n);
        if (n % 2 != 0) impares++;
        i++;
    }
    printf("Total de ímpares: %d\n", impares);
    return 0;
}
