
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-15.c
*/

int main() {
    float altC, largC, compC;
    float altCx, largCx, compCx;
    int total;

    printf("Dimensões do caminhão (A L C): ");
    scanf("%f %f %f", &altC, &largC, &compC);
    printf("Dimensões da caixa (A L C): ");
    scanf("%f %f %f", &altCx, &largCx, &compCx);

    total = (int)(altC / altCx) * (int)(largC / largCx) * (int)(compC / compCx);

    printf("Cabem %d caixas.\n", total);

    return 0;
}
