// JHMM-15.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-15 - Quantas caixas cabem dentro do caminhão              *");
    printf("\n********************************************************************************\n");

    float altC, largC, compC, altCx, largCx, compCx;
    int total;
    printf("Dimensões do caminhão (A L C): ");
    scanf("%f %f %f", &altC, &largC, &compC);
    printf("Dimensões da caixa (A L C): ");
    scanf("%f %f %f", &altCx, &largCx, &compCx);
    total = (int)(altC / altCx) * (int)(largC / largCx) * (int)(compC / compCx);
    printf("Cabem %d caixas.\n", total);

    return 0;
}
