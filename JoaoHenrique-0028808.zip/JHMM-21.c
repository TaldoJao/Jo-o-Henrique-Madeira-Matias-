// JHMM-21.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-21 - Número positivo ou negativo                          *");
    printf("\n********************************************************************************\n");

    float n;
    printf("Número: ");
    scanf("%f", &n);
    if (n > 0) printf("Positivo (Lucro)\n");
    else if (n < 0) printf("Negativo (Prejuízo)\n");
    else printf("Zero\n");

    return 0;
}
