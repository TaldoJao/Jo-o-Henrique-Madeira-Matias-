
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-21.c
*/

int main() {
    float n;
    printf("Número: ");
    scanf("%f", &n);

    if (n > 0) printf("Positivo (Lucro)\n");
    else if (n < 0) printf("Negativo (Prejuízo)\n");
    else printf("Zero\n");

    return 0;
}
