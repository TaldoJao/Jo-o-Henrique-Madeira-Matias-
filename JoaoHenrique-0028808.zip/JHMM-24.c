// JHMM-24.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-24 - Pode votar?                                          *");
    printf("\n********************************************************************************\n");

    int idade;
    printf("Idade: ");
    scanf("%d", &idade);
    if (idade >= 16) printf("Pode votar\n");
    else printf("Não pode votar\n");

    return 0;
}
