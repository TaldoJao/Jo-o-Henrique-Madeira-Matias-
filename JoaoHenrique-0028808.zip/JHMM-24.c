
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-24.c
*/

int main() {
    int idade;
    printf("Idade: ");
    scanf("%d", &idade);

    if (idade >= 16) printf("Pode votar\n");
    else printf("Não pode votar\n");

    return 0;
}
