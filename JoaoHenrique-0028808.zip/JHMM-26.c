
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-26.c
*/

int main() {
    for (int i = 1; i <= 10; i++) {
        printf("%d\n", i);
    }
    return 0;
}
