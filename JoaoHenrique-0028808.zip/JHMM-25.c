// JHMM-25.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-25 - Notas e aprovação                                    *");
    printf("\n********************************************************************************\n");

    float media;
    printf("Média: ");
    scanf("%f", &media);
    if (media >= 7.0) printf("Aprovado\n");
    else if (media >= 5.0) printf("Recuperação\n");
    else printf("Reprovado\n");

    return 0;
}
