
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-25.c
*/

int main() {
    float media;
    printf("Média: ");
    scanf("%f", &media);

    if (media >= 7.0) printf("Aprovado\n");
    else if (media >= 5.0) printf("Recuperação\n");
    else printf("Reprovado\n");

    return 0;
}
