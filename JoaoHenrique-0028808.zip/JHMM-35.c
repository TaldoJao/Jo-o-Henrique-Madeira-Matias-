// JHMM-35.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-35 - Números de Fibonacci (n termos)                      *");
    printf("\n********************************************************************************\n");

    int n, a = 0, b = 1, prox;
    printf("Termos: ");
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) {
        printf("%d ", a);
        prox = a + b;
        a = b;
        b = prox;
    }
    printf("\n");

    return 0;
}
