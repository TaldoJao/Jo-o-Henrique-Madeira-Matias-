
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-35.c
*/

int main() {
    int n, a = 0, b = 1, prox;
    printf("Termos: ");
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) {
        printf("%d ", a);
        prox = a + b;
        a = b;
        b = prox;
    }
    printf("\n");
    return 0;
}
