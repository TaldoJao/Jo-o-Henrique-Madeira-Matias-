
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-16.c
*/

int main() {
    int pedido;
    printf("Número do pedido: ");
    scanf("%d", &pedido);

    if (pedido % 3 == 0 && pedido % 5 == 0) {
        printf("Ganhou refrigerante e sobremesa!\n");
    } else if (pedido % 3 == 0) {
        printf("Ganhou um refrigerante!\n");
    } else if (pedido % 5 == 0) {
        printf("Ganhou uma sobremesa!\n");
    } else {
        printf("Sem brindes desta vez.\n");
    }

    return 0;
}
