// JHMM-16.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-16 - Múltiplo de 3 e/ou 5                                 *");
    printf("\n********************************************************************************\n");

    int pedido;
    printf("Número do pedido: ");
    scanf("%d", &pedido);
    if (pedido % 3 == 0 && pedido % 5 == 0) {
        printf("Ganhou refrigerante e sobremesa!\n");
    } else if (pedido % 3 == 0) {
        printf("Ganhou um refrigerante!\n");
    } else if (pedido % 5 == 0) {
        printf("Ganhou uma sobremesa!\n");
    } else {
        printf("Sem brindes desta vez.\n");
    }

    return 0;
}
