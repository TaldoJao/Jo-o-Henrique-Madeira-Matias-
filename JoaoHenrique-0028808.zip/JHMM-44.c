// JHMM-44.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-44 - Contar dígitos de um número                          *");
    printf("\n********************************************************************************\n");

    int n, cont = 0;
    printf("Número positivo: ");
    scanf("%d", &n);
    if (n == 0) cont = 1;
    else {
        while (n > 0) {
            n /= 10;
            cont++;
        }
    }
    printf("Dígitos: %d\n", cont);

    return 0;
}
