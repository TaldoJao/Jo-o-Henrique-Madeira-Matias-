
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-44.c
*/

int main() {
    int n, cont = 0;
    printf("Número positivo: ");
    scanf("%d", &n);
    if (n == 0) cont = 1;
    else {
        while (n > 0) {
            n /= 10;
            cont++;
        }
    }
    printf("Dígitos: %d\n", cont);
    return 0;
}
