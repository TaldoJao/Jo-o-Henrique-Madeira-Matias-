
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-22.c
*/

int main() {
    int n;
    printf("Número: ");
    scanf("%d", &n);

    if (n % 2 == 0) printf("Par\n");
    else printf("Ímpar\n");

    return 0;
}
