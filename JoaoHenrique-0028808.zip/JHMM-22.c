// JHMM-22.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-22 - Par ou ímpar                                         *");
    printf("\n********************************************************************************\n");

    int n;
    printf("Número: ");
    scanf("%d", &n);
    if (n % 2 == 0) printf("Par\n");
    else printf("Ímpar\n");

    return 0;
}
