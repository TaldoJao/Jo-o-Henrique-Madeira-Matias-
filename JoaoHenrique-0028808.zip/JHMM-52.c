// JHMM-52.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-52 - Soma até o número ser múltiplo de 10 (do...while)    *");
    printf("\n********************************************************************************\n");

    int n, soma = 0;
    do {
        printf("Número: ");
        scanf("%d", &n);
        soma += n;
    } while (n % 10 != 0);
    printf("Soma total: %d\n", soma);

    return 0;
}
