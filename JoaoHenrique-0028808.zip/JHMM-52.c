
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-52.c
*/

int main() {
    int n, soma = 0;
    do {
        printf("Número: ");
        scanf("%d", &n);
        soma += n;
    } while (n % 10 != 0);
    printf("Soma total: %d\n", soma);
    return 0;
}
