
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-39.c
*/

int main() {
    float n = -1;
    while (n <= 0) {
        printf("Digite um número positivo: ");
        scanf("%f", &n);
    }
    printf("Número aceito: %.2f\n", n);
    return 0;
}
