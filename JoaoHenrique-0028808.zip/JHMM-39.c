// JHMM-39.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-39 - Verificar se um número é positivo                    *");
    printf("\n********************************************************************************\n");

    float n = -1;
    while (n <= 0) {
        printf("Digite um número positivo: ");
        scanf("%f", &n);
    }
    printf("Número aceito: %.2f\n", n);

    return 0;
}
