// JHMM-51.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-51 - Contagem regressiva de 10 até 1 (do...while)         *");
    printf("\n********************************************************************************\n");

    int i = 10;
    do {
        printf("%d\n", i);
        i--;
    } while (i >= 1);

    return 0;
}
