
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-51.c
*/

int main() {
    int i = 10;
    do {
        printf("%d\n", i);
        i--;
    } while (i >= 1);
    return 0;
}
