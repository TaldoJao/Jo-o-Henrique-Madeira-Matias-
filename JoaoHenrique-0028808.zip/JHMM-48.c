
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-48.c
*/

int main() {
    int opt;
    do {
        printf("1 - Mensagem\n2 - Sair\nEscolha: ");
        scanf("%d", &opt);
        if (opt == 1) printf("Você escolheu a mensagem!\n");
    } while (opt != 2);
    return 0;
}
