// JHMM-48.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-48 - Menu com opção de sair (do...while)                  *");
    printf("\n********************************************************************************\n");

    int opt;
    do {
        printf("1 - Mensagem\n2 - Sair\nEscolha: ");
        scanf("%d", &opt);
        if (opt == 1) printf("Você escolheu a mensagem!\n");
    } while (opt != 2);

    return 0;
}
