
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-49.c
*/

int main() {
    int senha;
    do {
        printf("Senha: ");
        scanf("%d", &senha);
    } while (senha != 1111);
    printf("Acesso liberado!\n");
    return 0;
}
