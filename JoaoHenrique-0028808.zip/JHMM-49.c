// JHMM-49.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-49 - Pedir senha até acertar (do...while)                 *");
    printf("\n********************************************************************************\n");

    int senha;
    do {
        printf("Senha: ");
        scanf("%d", &senha);
    } while (senha != 1111);
    printf("Acesso liberado!\n");

    return 0;
}
