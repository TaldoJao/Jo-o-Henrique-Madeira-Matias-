// JHMM-57.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-57 - A Central do Brinquedo Eletrônico (switch...case)    *");
    printf("\n********************************************************************************\n");

    char cor[20];
    printf("Cor: ");
    scanf("%s", cor);
    if (strcmp(cor, "Verde") == 0) printf("Vamos brincar lá fora!\n");
    else if (strcmp(cor, "Amarelo") == 0) printf("Estou ficando com soninho...\n");
    else if (strcmp(cor, "Vermelho") == 0) printf("Estou com fome, hora do lanche!\n");
    else printf("Cor desconhecida\n");

    return 0;
}
