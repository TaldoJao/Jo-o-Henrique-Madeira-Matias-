
#include <stdio.h>
#include <string.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-57.c
*/

int main() {
    char cor[20];
    printf("Cor: ");
    scanf("%s", cor);

    if (strcmp(cor, "Verde") == 0) printf("Vamos brincar lá fora!\n");
    else if (strcmp(cor, "Amarelo") == 0) printf("Estou ficando com soninho...\n");
    else if (strcmp(cor, "Vermelho") == 0) printf("Estou com fome, hora do lanche!\n");
    else printf("Cor desconhecida\n");

    return 0;
}
