
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-34.c
*/

int main() {
    int n, cont = 0;
    printf("Número: ");
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) {
        if (n % i == 0) cont++;
    }
    if (cont == 2) printf("Primo\n");
    else printf("Não é primo\n");
    return 0;
}
