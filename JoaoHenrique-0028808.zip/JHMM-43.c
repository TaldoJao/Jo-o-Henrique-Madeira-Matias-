
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-43.c
*/

int main() {
    int soma = 0, i = 1;
    while (i <= 100) {
        if (i % 2 == 0) soma += i;
        i++;
    }
    printf("Soma dos pares: %d\n", soma);
    return 0;
}
