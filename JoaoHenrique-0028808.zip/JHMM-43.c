// JHMM-43.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-43 - Soma dos pares entre 1 e 100                         *");
    printf("\n********************************************************************************\n");

    int soma = 0, i = 1;
    while (i <= 100) {
        if (i % 2 == 0) soma += i;
        i++;
    }
    printf("Soma dos pares: %d\n", soma);

    return 0;
}
