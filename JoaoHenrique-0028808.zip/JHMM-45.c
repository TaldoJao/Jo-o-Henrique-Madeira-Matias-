
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-45.c
*/

int main() {
    int opt = 0;
    while (opt != 3) {
        printf("1. Saldo\n2. Saque\n3. Sair\nEscolha: ");
        scanf("%d", &opt);
    }
    return 0;
}
