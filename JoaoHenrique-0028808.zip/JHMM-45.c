// JHMM-45.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-45 - Menu até escolher sair                               *");
    printf("\n********************************************************************************\n");

    int opt = 0;
    while (opt != 3) {
        printf("1. Saldo\n2. Saque\n3. Sair\nEscolha: ");
        scanf("%d", &opt);
    }

    return 0;
}
