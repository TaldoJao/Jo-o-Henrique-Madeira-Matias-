// JHMM-20.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-20 - Ano bissexto                                         *");
    printf("\n********************************************************************************\n");

    int ano;
    printf("Ano: ");
    scanf("%d", &ano);
    if ((ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0)) {
        printf("Bissexto\n");
    } else {
        printf("Não é bissexto\n");
    }

    return 0;
}
