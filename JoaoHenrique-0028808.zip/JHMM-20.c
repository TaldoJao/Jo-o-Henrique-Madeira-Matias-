
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-20.c
*/

int main() {
    int ano;
    printf("Ano: ");
    scanf("%d", &ano);

    if ((ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0)) {
        printf("Bissexto\n");
    } else {
        printf("Não é bissexto\n");
    }

    return 0;
}
