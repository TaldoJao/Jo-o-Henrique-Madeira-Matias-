
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-56.c
*/

int main() {
    int combo;
    printf("Escolha o combo (1-4): ");
    scanf("%d", &combo);
    switch (combo) {
        case 1: printf("Combo Hambúrguer + Batata + Refri - R$ 30,00\n"); break;
        case 2: printf("Combo Pizza Brotinho + Refri - R$ 25,00\n"); break;
        case 3: printf("Combo Salada + Suco Natural - R$ 22,00\n"); break;
        case 4: printf("Combo Balde de Frango + Molho - R$ 35,00\n"); break;
        default: printf("Opção inválida! Escolha de 1 a 4.\n");
    }
    return 0;
}
