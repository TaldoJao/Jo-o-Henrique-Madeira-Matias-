// JHMM-53.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-53 - Confirmar saída com 's' (do...while)                 *");
    printf("\n********************************************************************************\n");

    char sair;
    do {
        printf("Deseja sair? (s/n): ");
        scanf(" %c", &sair);
    } while (sair != 's');

    return 0;
}
