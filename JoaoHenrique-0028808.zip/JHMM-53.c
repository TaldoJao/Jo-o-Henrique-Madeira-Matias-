
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-53.c
*/

int main() {
    char sair;
    do {
        printf("Deseja sair? (s/n): ");
        scanf(" %c", &sair);
    } while (sair != 's');
    return 0;
}
