
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-31.c
*/

int main() {
    for (int i = 10; i >= 1; i--) {
        printf("%d\n", i);
    }
    return 0;
}
