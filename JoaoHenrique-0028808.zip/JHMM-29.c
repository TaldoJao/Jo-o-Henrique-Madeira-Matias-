
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-29.c
*/

int main() {
    for (int i = 0; i <= 50; i += 2) {
        printf("%d\n", i);
    }
    return 0;
}
