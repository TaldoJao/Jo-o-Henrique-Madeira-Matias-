// JHMM-29.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-29 - Números pares de 0 a 50                              *");
    printf("\n********************************************************************************\n");

    for (int i = 0; i <= 50; i += 2) {
        printf("%d\n", i);
    }

    return 0;
}
