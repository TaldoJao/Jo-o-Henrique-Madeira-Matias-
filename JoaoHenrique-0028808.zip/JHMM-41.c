
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-41.c
*/

int main() {
    int n, i = 1, cont = 0;
    printf("Número: ");
    scanf("%d", &n);
    while (i <= n) {
        if (n % i == 0) cont++;
        i++;
    }
    if (cont == 2) printf("Primo\n");
    else printf("Não é primo\n");
    return 0;
}
