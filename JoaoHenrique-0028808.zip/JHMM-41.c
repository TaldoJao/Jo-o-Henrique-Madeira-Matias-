// JHMM-41.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-41 - Número primo com while                               *");
    printf("\n********************************************************************************\n");

    int n, i = 1, cont = 0;
    printf("Número: ");
    scanf("%d", &n);
    while (i <= n) {
        if (n % i == 0) cont++;
        i++;
    }
    if (cont == 2) printf("Primo\n");
    else printf("Não é primo\n");

    return 0;
}
