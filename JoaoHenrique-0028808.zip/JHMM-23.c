
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-23.c
*/

int main() {
    float a, b;
    printf("Dois números: ");
    scanf("%f %f", &a, &b);

    if (a > b) printf("Maior: %.2f\n", a);
    else if (b > a) printf("Maior: %.2f\n", b);
    else printf("São iguais\n");

    return 0;
}
