// JHMM-23.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-23 - Maior de dois números                                *");
    printf("\n********************************************************************************\n");

    float a, b;
    printf("Dois números: ");
    scanf("%f %f", &a, &b);
    if (a > b) printf("Maior: %.2f\n", a);
    else if (b > a) printf("Maior: %.2f\n", b);
    else printf("São iguais\n");

    return 0;
}
