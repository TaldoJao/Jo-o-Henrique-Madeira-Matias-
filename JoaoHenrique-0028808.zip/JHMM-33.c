
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-33.c
*/

int main() {
    for (int i = 1; i <= 30; i++) {
        if (i % 3 == 0) printf("%d\n", i);
    }
    return 0;
}
