// JHMM-33.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-33 - Múltiplos de 3 entre 1 e 30                          *");
    printf("\n********************************************************************************\n");

    for (int i = 1; i <= 30; i++) {
        if (i % 3 == 0) printf("%d\n", i);
    }

    return 0;
}
