
#include <stdio.h>
#include <string.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-18.c
*/

int main() {
    char usuario[20], senha[20];
    printf("Usuário: ");
    scanf("%s", usuario);
    printf("Senha: ");
    scanf("%s", senha);

    if (strcmp(usuario, "aluno") == 0 && strcmp(senha, "1234") == 0) {
        printf("Acesso permitido\n");
    } else {
        printf("Acesso negado\n");
    }

    return 0;
}
