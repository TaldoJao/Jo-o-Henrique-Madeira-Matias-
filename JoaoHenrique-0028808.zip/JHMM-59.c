
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-59.c
*/

int main() {
    char dir;
    printf("Direção (N, S, L, O): ");
    scanf(" %c", &dir);
    switch (dir) {
        case 'N': printf("Seguir para o Norte.\n"); break;
        case 'S': printf("Seguir para o Sul.\n"); break;
        case 'L': printf("Virar à Leste (Direita).\n"); break;
        case 'O': printf("Virar à Oeste (Esquerda).\n"); break;
        default: printf("Comando inválido! Pare o robô.\n");
    }
    return 0;
}
