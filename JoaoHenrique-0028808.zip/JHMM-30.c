// JHMM-30.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-30 - Fatorial de um número                                *");
    printf("\n********************************************************************************\n");

    int n;
    long long fat = 1;
    printf("Número: ");
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) {
        fat *= i;
    }
    printf("Fatorial: %lld\n", fat);

    return 0;
}
