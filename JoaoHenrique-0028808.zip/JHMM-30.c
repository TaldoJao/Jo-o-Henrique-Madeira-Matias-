
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-30.c
*/

int main() {
    int n;
    long long fat = 1;
    printf("Número: ");
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) {
        fat *= i;
    }
    printf("Fatorial: %lld\n", fat);
    return 0;
}
