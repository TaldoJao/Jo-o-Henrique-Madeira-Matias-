
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-58.c
*/

int main() {
    float n1, n2;
    char op;
    printf("Operação (ex: 10 + 5): ");
    scanf("%f %c %f", &n1, &op, &n2);
    switch (op) {
        case '+': printf("Resultado: %.2f\n", n1 + n2); break;
        case '-': printf("Resultado: %.2f\n", n1 - n2); break;
        case '*': printf("Resultado: %.2f\n", n1 * n2); break;
        case '/': 
            if (n2 != 0) printf("Resultado: %.2f\n", n1 / n2);
            else printf("Erro: Divisão por zero!\n");
            break;
        default: printf("Operação matemática não reconhecida\n");
    }
    return 0;
}
