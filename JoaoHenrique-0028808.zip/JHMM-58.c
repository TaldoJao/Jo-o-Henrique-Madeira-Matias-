// JHMM-58.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-58 - A Calculadora de Bolso de 4 Operações (switch...ca   *");
    printf("\n********************************************************************************\n");

    float n1, n2;
    char op;
    printf("Operação (ex: 10 + 5): ");
    scanf("%f %c %f", &n1, &op, &n2);
    switch (op) {
        case '+': printf("Resultado: %.2f\n", n1 + n2); break;
        case '-': printf("Resultado: %.2f\n", n1 - n2); break;
        case '*': printf("Resultado: %.2f\n", n1 * n2); break;
        case '/': 
            if (n2 != 0) printf("Resultado: %.2f\n", n1 / n2);
            else printf("Erro: Divisão por zero!\n");
            break;
        default: printf("Operação matemática não reconhecida\n");
    }

    return 0;
}
