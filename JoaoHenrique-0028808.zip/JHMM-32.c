// JHMM-32.c
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "Portuguese");

    printf("\n********************************************************************************");
    printf("\n* Aluno: JOAO HENRIQUE MADEIRA MATIAS - RA 0028808                             *");
    printf("\n* Programa JPA-32 - Quadrado dos números de 1 a 10                       *");
    printf("\n********************************************************************************\n");

    for (int i = 1; i <= 10; i++) {
        printf("%d^2 = %d\n", i, i * i);
    }

    return 0;
}
