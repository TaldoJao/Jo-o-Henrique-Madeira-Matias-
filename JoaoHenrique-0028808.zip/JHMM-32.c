
#include <stdio.h>

/* 
   ALUNO: JOAO HENRIQUE MADEIRA MATIAS
   RA: 0028808
   JHMM-32.c
*/

int main() {
    for (int i = 1; i <= 10; i++) {
        printf("%d^2 = %d\n", i, i * i);
    }
    return 0;
}
